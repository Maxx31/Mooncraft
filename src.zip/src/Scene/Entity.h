#pragma once
#include "../MCraft.h"

class Entity {
public:
  void init();
  void update();
  void render();
};