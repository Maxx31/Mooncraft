#include "Entity.h"

void Entity::init() {}
void Entity::update() {}
void Entity::render() {}
